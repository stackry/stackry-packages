#!/usr/bin/env python3
"""Collect and evaluate Stackry Vision production-qualification evidence.

This harness is read-only against Vision and station APIs. It does not create
accuracy evidence: dimension gates are evaluated only from caller-supplied,
caliper-truthed placement rows.
"""
from __future__ import annotations

import argparse
import base64
import csv
import hashlib
import ipaddress
import json
import math
import os
import re
import shlex
import shutil
import subprocess
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
from collections import Counter
from collections.abc import Callable, Mapping, Sequence
from datetime import datetime, timedelta, timezone
from pathlib import Path


EVIDENCE_SCHEMA_VERSION = 5
CONFIG_SCHEMA_VERSION = 3
MIN_PRODUCTION_DURATION_SECONDS = 72 * 60 * 60
MAX_PRODUCTION_SAMPLE_INTERVAL_SECONDS = 60
REQUIRED_RECOVERY_SCENARIOS = (
    "cold_boot",
    "warm_reboot",
    "vision_restart",
    "agent_restart",
    "docker_restart",
    "network_loss",
    "stackry_api_loss",
    "camera_daemon_restart",
    "controlled_power_interruption",
)
EXPECTED_GATE_NAMES = (
    "evidence_complete",
    "sample_timeline",
    "runtime_identity",
    "dimension_accuracy",
    "settle_latency",
    "capture_latency",
    "temperature_c",
    "rss_mb",
    "event_loss_count",
    "manual_interventions",
    "throttling",
    "recovery_scenarios",
)
SAMPLE_TIMESTAMP_TOLERANCE_SECONDS = 2.0
_SAMPLE_INTERRUPTION_SCENARIOS = frozenset(
    {"warm_reboot", "controlled_power_interruption"}
)
_DIMENSION_AXES = ("length", "width", "height")
_REQUIRED_LIMITS = (
    "dimension_error_mm",
    "settle_latency_ms_p95",
    "capture_latency_ms_p95",
    "max_temperature_c",
    "max_throttled_samples",
    "max_rss_mb",
    "max_event_loss_count",
    "max_manual_interventions",
    "min_placements_per_class",
    "min_placements_per_object_orientation",
)
_DURATION_RE = re.compile(r"^(?P<value>[0-9]+(?:\.[0-9]+)?)(?P<unit>s|m|h)?$")
_DIGEST_RE = re.compile(r"^(?:[^@\s]+@)?sha256:[0-9a-f]{64}$")
_TEMP_RE = re.compile(r"(?:CPU|GPU|SOC|tj|Tboard|Tdiode)[^@\s]*@(?P<value>[0-9.]+)C", re.I)
_RAM_RE = re.compile(r"RAM\s+(?P<used>[0-9]+)/[0-9]+MB", re.I)


class ConfigError(ValueError):
    """Raised when a qualification profile is ambiguous or incomplete."""


def _canonical_json_bytes(value: object) -> bytes:
    return json.dumps(
        value, sort_keys=True, separators=(",", ":"), ensure_ascii=True
    ).encode("utf-8")


def _canonical_digest(value: object) -> str:
    return f"sha256:{hashlib.sha256(_canonical_json_bytes(value)).hexdigest()}"


def _unsigned_evidence(evidence: Mapping[str, object]) -> dict[str, object]:
    payload = json.loads(json.dumps(evidence))
    if not isinstance(payload, dict):
        raise ConfigError("qualification evidence must be an object")
    payload.pop("attestation", None)
    return payload


def _run_openssl(args: Sequence[str], *, payload: bytes | None = None) -> bytes:
    executable = shutil.which("openssl")
    if executable is None:
        raise ConfigError("openssl is required for qualification evidence attestation")
    try:
        completed = subprocess.run(  # noqa: S603 - fixed executable and explicit argv
            [executable, *args],
            input=payload,
            check=False,
            capture_output=True,
        )
    except OSError as exc:
        raise ConfigError(f"cannot execute openssl: {exc}") from exc
    if completed.returncode != 0:
        detail = completed.stderr.decode("utf-8", errors="replace").strip()
        raise ConfigError(f"openssl command failed: {detail or 'unknown error'}")
    return completed.stdout


def _public_key_material(private_key: Path) -> tuple[bytes, bytes, str]:
    if not private_key.is_file():
        raise ConfigError(f"agent private key does not exist: {private_key}")
    public_pem = _run_openssl(["pkey", "-in", str(private_key), "-pubout"])
    public_der = _run_openssl(["pkey", "-pubin", "-outform", "DER"], payload=public_pem)
    digest = hashlib.sha256(public_der).hexdigest().upper()
    fingerprint = ":".join(digest[index : index + 2] for index in range(0, len(digest), 2))
    return public_pem, public_der, fingerprint


def _validate_agent_private_key(
    private_key: Path, *, require_root_owner: bool = True
) -> None:
    try:
        metadata = private_key.lstat()
    except OSError as exc:
        raise ConfigError(f"cannot inspect agent private key {private_key}: {exc}") from exc
    if private_key.is_symlink() or not private_key.is_file():
        raise ConfigError("agent private key must be a regular file, not a symlink")
    if metadata.st_mode & 0o077:
        raise ConfigError("agent private key permissions must be 0600 or stricter")
    if require_root_owner and metadata.st_uid != 0:
        raise ConfigError("agent private key must be owned by root")


def _sign_evidence(evidence: dict[str, object], private_key: Path) -> dict[str, object]:
    evidence.pop("attestation", None)
    public_pem, _public_der, fingerprint = _public_key_material(private_key)
    signature = _run_openssl(
        ["dgst", "-sha256", "-sign", str(private_key)],
        payload=_canonical_json_bytes(evidence),
    )
    attestation: dict[str, object] = {
        "algorithm": "ecdsa-p256-sha256",
        "public_key_pem": public_pem.decode("ascii"),
        "fingerprint": fingerprint,
        "signature": base64.b64encode(signature).decode("ascii"),
    }
    evidence["attestation"] = attestation
    return attestation


def _verify_evidence_attestation(
    evidence: Mapping[str, object], approved_appliance_fingerprint: str
) -> None:
    approved = approved_appliance_fingerprint.strip().upper()
    fingerprint_pattern = r"(?:[0-9A-F]{2}:){31}[0-9A-F]{2}"
    if re.fullmatch(fingerprint_pattern, approved) is None:
        raise ConfigError("approved appliance fingerprint must be a SHA-256 fingerprint")
    attestation = evidence.get("attestation")
    if not isinstance(attestation, Mapping):
        raise ConfigError("evidence attestation is required")
    if attestation.get("algorithm") != "ecdsa-p256-sha256":
        raise ConfigError("evidence attestation algorithm must be ecdsa-p256-sha256")
    fingerprint = str(attestation.get("fingerprint", "")).strip().upper()
    if fingerprint != approved:
        raise ConfigError("evidence attestation does not match the approved appliance")
    public_key_value = attestation.get("public_key_pem")
    if not isinstance(public_key_value, str):
        raise ConfigError("evidence attestation public_key_pem must be text")
    try:
        public_pem = public_key_value.encode("ascii", errors="strict")
    except UnicodeEncodeError as exc:
        raise ConfigError("evidence attestation public_key_pem must be ASCII PEM") from exc
    public_der = _run_openssl(["pkey", "-pubin", "-outform", "DER"], payload=public_pem)
    observed_digest = hashlib.sha256(public_der).hexdigest().upper()
    observed_fingerprint = ":".join(
        observed_digest[index : index + 2]
        for index in range(0, len(observed_digest), 2)
    )
    if observed_fingerprint != fingerprint:
        raise ConfigError("evidence public key does not match its appliance fingerprint")
    try:
        signature = base64.b64decode(
            str(attestation.get("signature", "")), validate=True
        )
    except (ValueError, base64.binascii.Error) as exc:
        raise ConfigError("evidence attestation signature is not valid base64") from exc
    if not signature:
        raise ConfigError("evidence attestation signature is required")
    with tempfile.TemporaryDirectory(prefix="stackry-qualification-verify-") as directory:
        public_path = Path(directory) / "public.pem"
        signature_path = Path(directory) / "signature.der"
        public_path.write_bytes(public_pem)
        signature_path.write_bytes(signature)
        try:
            _run_openssl(
                [
                    "dgst",
                    "-sha256",
                    "-verify",
                    str(public_path),
                    "-signature",
                    str(signature_path),
                ],
                payload=_canonical_json_bytes(_unsigned_evidence(evidence)),
            )
        except ConfigError as exc:
            raise ConfigError("evidence attestation signature verification failed") from exc


def _parse_timestamp(value: object, field: str) -> datetime:
    raw = str(value).strip()
    if not raw:
        raise ValueError(f"{field} is required")
    normalized = f"{raw[:-1]}+00:00" if raw.endswith("Z") else raw
    try:
        parsed = datetime.fromisoformat(normalized)
    except ValueError as exc:
        raise ValueError(f"{field} must be an ISO-8601 timestamp") from exc
    if parsed.tzinfo is None:
        raise ValueError(f"{field} must include a timezone")
    return parsed.astimezone(timezone.utc)


def _validate_sample_timeline(
    samples: Sequence[object],
    *,
    started_at: object,
    completed_at: object | None,
    interval_seconds: float,
    allowed_interruptions: Sequence[tuple[datetime, datetime, str]] = (),
    enforce_cadence: bool = True,
) -> list[datetime]:
    run_started = _parse_timestamp(started_at, "qualification started_at")
    run_completed = (
        _parse_timestamp(completed_at, "qualification completed_at")
        if completed_at is not None
        else None
    )
    timestamps: list[datetime] = []
    for index, sample in enumerate(samples, start=1):
        if not isinstance(sample, Mapping):
            raise ValueError(f"sample {index} must be an object")
        sampled_at = _parse_timestamp(sample.get("sampled_at"), f"sample {index} sampled_at")
        if sampled_at < run_started:
            raise ValueError(f"sample {index} predates qualification started_at")
        if run_completed is not None and sampled_at > run_completed:
            raise ValueError(f"sample {index} follows qualification completed_at")
        if timestamps:
            gap = (sampled_at - timestamps[-1]).total_seconds()
            if gap <= 0:
                raise ValueError("qualification sample timestamps must be strictly increasing")
            accepted_cadence = interval_seconds + SAMPLE_TIMESTAMP_TOLERANCE_SECONDS
            interruption_covers_gap = any(
                interruption_started <= timestamps[-1] + timedelta(seconds=accepted_cadence)
                and interruption_completed >= sampled_at - timedelta(seconds=accepted_cadence)
                for interruption_started, interruption_completed, _name in allowed_interruptions
            )
            if enforce_cadence and gap > accepted_cadence and not interruption_covers_gap:
                raise ValueError(
                    f"qualification sample gap {gap:.3f}s exceeds accepted cadence"
                )
        timestamps.append(sampled_at)
    return timestamps


def _sampled_active_duration(
    timestamps: Sequence[datetime], interval_seconds: float
) -> float:
    if len(timestamps) < 2:
        return 0.0
    accepted_cadence = interval_seconds + SAMPLE_TIMESTAMP_TOLERANCE_SECONDS
    return sum(
        gap
        for previous, current in zip(timestamps, timestamps[1:])
        if 0 < (gap := (current - previous).total_seconds()) <= accepted_cadence
    )


def verify_promotion_evidence(
    evidence: Mapping[str, object],
    *,
    source_digest: str,
    approved_config_digest: str,
    approved_truth_digest: str,
    approved_appliance_fingerprint: str,
) -> None:
    """Independently recompute the complete contract before stable promotion."""
    if evidence.get("schema_version") != EVIDENCE_SCHEMA_VERSION:
        raise ConfigError(f"evidence schema_version must be {EVIDENCE_SCHEMA_VERSION}")
    if evidence.get("production_acceptance") is not True:
        raise ConfigError("evidence production_acceptance must be true")
    if not str(evidence.get("profile_version", "")).strip():
        raise ConfigError("evidence profile_version is required")
    _verify_evidence_attestation(evidence, approved_appliance_fingerprint)
    for field, expected in (
        ("config_digest", approved_config_digest),
        ("truth_digest", approved_truth_digest),
    ):
        if _DIGEST_RE.fullmatch(expected) is None:
            raise ConfigError(f"approved {field} must be an immutable sha256 digest")
        if evidence.get(field) != expected:
            raise ConfigError(f"evidence {field} does not match the approved digest")

    accepted_profile = evidence.get("accepted_profile")
    if not isinstance(accepted_profile, Mapping):
        raise ConfigError("evidence accepted_profile must be an object")
    truth_corpus = evidence.get("truth_corpus")
    if not isinstance(truth_corpus, list) or any(
        not isinstance(row, Mapping) for row in truth_corpus
    ):
        raise ConfigError("evidence truth_corpus must be an array of objects")
    if _canonical_digest(accepted_profile) != approved_config_digest:
        raise ConfigError("embedded accepted_profile does not match the approved digest")
    if _canonical_digest(truth_corpus) != approved_truth_digest:
        raise ConfigError("embedded truth_corpus does not match the approved digest")
    validate_config(accepted_profile)
    if evidence.get("profile_version") != accepted_profile.get("profile_version"):
        raise ConfigError("evidence profile_version does not match accepted_profile")

    duration = _number(
        evidence.get("duration_seconds"), "evidence duration_seconds", minimum=0.001
    )
    if duration < MIN_PRODUCTION_DURATION_SECONDS:
        raise ConfigError("evidence duration_seconds must cover at least 72 hours")
    interval = _number(
        evidence.get("sample_interval_seconds"),
        "evidence sample_interval_seconds",
        minimum=0.001,
    )
    if interval > MAX_PRODUCTION_SAMPLE_INTERVAL_SECONDS:
        raise ConfigError("evidence sample_interval_seconds must be at most 60 seconds")
    completed = _number(
        evidence.get("completed_duration_seconds"),
        "evidence completed_duration_seconds",
        minimum=0,
    )
    if completed < duration:
        raise ConfigError("evidence completed duration is shorter than its accepted duration")
    if duration != float(accepted_profile["duration_seconds"]):
        raise ConfigError("evidence duration_seconds does not match accepted_profile")
    if interval != float(accepted_profile["sample_interval_seconds"]):
        raise ConfigError("evidence sample_interval_seconds does not match accepted_profile")

    samples = evidence.get("samples")
    if not isinstance(samples, list):
        raise ConfigError("evidence samples must be an array")
    expected_samples = math.ceil(duration / interval) + 1
    if len(samples) < expected_samples:
        raise ConfigError("evidence sample count does not cover its accepted duration")
    failures = evidence.get("failures")
    if not isinstance(failures, list):
        raise ConfigError("evidence failures must be an array")

    recomputed = json.loads(json.dumps(evidence))
    assert isinstance(recomputed, dict)
    _evaluate(recomputed, accepted_profile, truth_corpus)
    for field in ("status", "identity", "metrics", "gates", "summary"):
        if evidence.get(field) != recomputed.get(field):
            raise ConfigError(f"evidence {field} does not match recomputed results")
    if recomputed.get("status") != "passed":
        raise ConfigError("recomputed evidence status must be passed")

    identity = recomputed.get("identity")
    assert isinstance(identity, Mapping)
    observed_digest = str(identity.get("digest", ""))
    if observed_digest != source_digest and not observed_digest.endswith(
        f"@{source_digest}"
    ):
        raise ConfigError("evidence runtime digest does not match source_digest")
    cameras = identity.get("cameras")
    if not isinstance(cameras, Mapping) or len(cameras) != 2:
        raise ConfigError("evidence identity must contain exactly two cameras")
    for alias, camera in cameras.items():
        if not isinstance(camera, Mapping) or not str(camera.get("serial", "")).strip():
            raise ConfigError(f"evidence camera {alias} must include a serial")

    gates = recomputed.get("gates")
    assert isinstance(gates, list)
    names = [str(item.get("name", "")) for item in gates]
    if sorted(names) != sorted(EXPECTED_GATE_NAMES):
        raise ConfigError("evidence gates do not match the complete required gate set")
    if any(item.get("passed") is not True for item in gates):
        raise ConfigError("every evidence gate must pass")

    summary = recomputed.get("summary")
    assert isinstance(summary, Mapping)
    expected_summary = {
        "samples": len(samples),
        "failures": len(failures),
        "passed_gates": len(gates),
        "total_gates": len(gates),
    }
    for field, expected in expected_summary.items():
        if summary.get(field) != expected:
            raise ConfigError(f"evidence summary.{field} does not match the evidence")


def _number(value: object, field: str, *, minimum: float = 0.0) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ConfigError(f"{field} must be numeric")
    result = float(value)
    if not math.isfinite(result) or result < minimum:
        raise ConfigError(f"{field} must be finite and >= {minimum}")
    return result


def _integer(value: object, field: str, *, minimum: int = 0) -> int:
    result = _number(value, field, minimum=float(minimum))
    if not result.is_integer():
        raise ConfigError(f"{field} must be a whole number")
    return int(result)


def validate_config(config: Mapping[str, object]) -> None:
    """Reject implicit defaults for every production acceptance limit."""
    if config.get("schema_version") != CONFIG_SCHEMA_VERSION:
        raise ConfigError(f"schema_version must be {CONFIG_SCHEMA_VERSION}")
    if not str(config.get("profile_version", "")).strip():
        raise ConfigError("profile_version is required")
    if config.get("production_acceptance") is not True:
        raise ConfigError("production_acceptance must be true")
    duration = _number(config.get("duration_seconds"), "duration_seconds", minimum=0.001)
    if duration < MIN_PRODUCTION_DURATION_SECONDS:
        raise ConfigError("duration_seconds must cover at least 72 hours")
    interval = _number(
        config.get("sample_interval_seconds"),
        "sample_interval_seconds",
        minimum=0.001,
    )
    if interval > MAX_PRODUCTION_SAMPLE_INTERVAL_SECONDS:
        raise ConfigError("sample_interval_seconds must be at most 60 seconds")

    recovery_scenarios = config.get("required_recovery_scenarios")
    if (
        not isinstance(recovery_scenarios, list)
        or len(recovery_scenarios) != len(REQUIRED_RECOVERY_SCENARIOS)
        or len(set(map(str, recovery_scenarios))) != len(REQUIRED_RECOVERY_SCENARIOS)
        or set(map(str, recovery_scenarios)) != set(REQUIRED_RECOVERY_SCENARIOS)
    ):
        raise ConfigError(
            "required_recovery_scenarios must contain the complete required recovery matrix"
        )

    recovery_timeouts = config.get("recovery_timeout_seconds")
    if (
        not isinstance(recovery_timeouts, Mapping)
        or set(map(str, recovery_timeouts)) != set(REQUIRED_RECOVERY_SCENARIOS)
    ):
        raise ConfigError(
            "recovery_timeout_seconds must define the complete required recovery matrix"
        )
    for name in REQUIRED_RECOVERY_SCENARIOS:
        _number(
            recovery_timeouts[name],
            f"recovery_timeout_seconds.{name}",
            minimum=0.001,
        )

    cameras = config.get("required_cameras")
    if (
        not isinstance(cameras, list)
        or len(cameras) != 2
        or len(set(map(str, cameras))) != 2
        or any(not str(camera).strip() for camera in cameras)
    ):
        raise ConfigError("required_cameras must name exactly two distinct cameras")

    endpoints = config.get("endpoints")
    if not isinstance(endpoints, Mapping) or not endpoints:
        raise ConfigError("endpoints must be a non-empty mapping")
    for name, endpoint in endpoints.items():
        if not isinstance(endpoint, Mapping) or not str(endpoint.get("path", "")).startswith("/"):
            raise ConfigError(f"endpoints.{name}.path must start with /")

    paths = config.get("evidence_paths")
    required_paths = {
        "version",
        "digest",
        "camera_identities",
        "temperature_c",
        "throttle_active",
        "rss_mb",
        "event_loss_count",
        "manual_interventions",
        "recovery_scenarios",
    }
    if not isinstance(paths, Mapping):
        raise ConfigError("evidence_paths must be a mapping")
    for name in sorted(required_paths):
        if not str(paths.get(name, "")).startswith("/"):
            raise ConfigError(f"evidence_paths.{name} is required and must be a JSON pointer")

    limits = config.get("limits")
    if not isinstance(limits, Mapping):
        raise ConfigError("limits must be a mapping")
    for name in _REQUIRED_LIMITS:
        if name not in limits:
            raise ConfigError(f"limits.{name} is required")
    classes = limits["dimension_error_mm"]
    if not isinstance(classes, Mapping) or not classes:
        raise ConfigError("limits.dimension_error_mm must define at least one class")
    for class_name, class_limits in classes.items():
        if not isinstance(class_limits, Mapping):
            raise ConfigError(f"dimension_error_mm.{class_name} must be a mapping")
        values = [
            _number(class_limits.get(percentile), f"dimension_error_mm.{class_name}.{percentile}")
            for percentile in ("p50", "p95", "max")
        ]
        if values != sorted(values):
            raise ConfigError(
                f"dimension_error_mm.{class_name} must satisfy p50 <= p95 <= max"
            )
    count_limits = {
        "max_throttled_samples",
        "max_event_loss_count",
        "max_manual_interventions",
    }
    minimum_limits = {
        "min_placements_per_class",
        "min_placements_per_object_orientation",
    }
    for name in _REQUIRED_LIMITS[1:]:
        if name in count_limits:
            _integer(limits[name], f"limits.{name}")
            continue
        if name in minimum_limits:
            _integer(limits[name], f"limits.{name}", minimum=1)
            continue
        _number(limits[name], f"limits.{name}")

    commands = config.get("commands", {})
    if not isinstance(commands, Mapping):
        raise ConfigError("commands must be a mapping")
    for name, command in commands.items():
        if not isinstance(command, Mapping):
            raise ConfigError(f"commands.{name} must be a mapping")
        argv = command.get("argv")
        if not isinstance(argv, list) or not argv or any(not isinstance(v, str) for v in argv):
            raise ConfigError(f"commands.{name}.argv must be a non-empty string list")
        if command.get("parser", "raw") not in {
            "raw",
            "json",
            "number",
            "boolean",
            "tegrastats",
            "nvpmodel",
        }:
            raise ConfigError(
                f"commands.{name}.parser must be raw, json, number, boolean, "
                "tegrastats, or nvpmodel"
            )


def _percentile(values: Sequence[float], percentile: float) -> float:
    if not values:
        raise ValueError("percentile requires at least one value")
    ordered = sorted(float(value) for value in values)
    rank = max(1, math.ceil(percentile * len(ordered)))
    return ordered[rank - 1]


def _truth_number(row: Mapping[str, object], key: str, placement_id: str) -> float:
    value = row.get(key)
    if isinstance(value, bool):
        raise ValueError(f"placement {placement_id}: {key} must be numeric")
    try:
        result = float(value)  # type: ignore[arg-type]
    except (TypeError, ValueError) as exc:
        raise ValueError(f"placement {placement_id}: {key} must be numeric") from exc
    if not math.isfinite(result) or result < 0:
        raise ValueError(f"placement {placement_id}: {key} must be finite and >= 0")
    return result


def calculate_dimension_metrics(
    truth_rows: Sequence[Mapping[str, object]],
) -> dict[str, dict[str, float | int]]:
    """Calculate absolute axis errors by parcel class from explicit truth rows."""
    grouped: dict[str, dict[str, object]] = {}
    seen_ids: set[str] = set()
    for index, row in enumerate(truth_rows, start=1):
        placement_id = str(row.get("placement_id", "")).strip()
        class_name = str(row.get("class", "")).strip()
        if not placement_id:
            raise ValueError(f"truth row {index}: placement_id is required")
        if placement_id in seen_ids:
            raise ValueError(f"duplicate placement_id: {placement_id}")
        seen_ids.add(placement_id)
        if not class_name:
            raise ValueError(f"placement {placement_id}: class is required")
        errors: list[float] = []
        for axis in _DIMENSION_AXES:
            truth = _truth_number(row, f"truth_{axis}_mm", placement_id)
            measured = _truth_number(row, f"measured_{axis}_mm", placement_id)
            errors.append(abs(measured - truth))
        bucket = grouped.setdefault(class_name, {"placements": 0, "errors": []})
        bucket["placements"] = int(bucket["placements"]) + 1
        bucket["errors"].extend(errors)  # type: ignore[union-attr]

    report: dict[str, dict[str, float | int]] = {}
    for class_name, bucket in grouped.items():
        errors = bucket["errors"]
        assert isinstance(errors, list)
        report[class_name] = {
            "placements": int(bucket["placements"]),
            "axis_measurements": len(errors),
            "p50_error_mm": _percentile(errors, 0.50),
            "p95_error_mm": _percentile(errors, 0.95),
            "max_error_mm": max(errors),
        }
    return report


def _json_pointer(document: object, pointer: str) -> object:
    current = document
    for raw_part in pointer.split("/")[1:]:
        part = raw_part.replace("~1", "/").replace("~0", "~")
        if isinstance(current, Mapping) and part in current:
            current = current[part]
        elif isinstance(current, list) and part.isdigit() and int(part) < len(current):
            current = current[int(part)]
        else:
            raise KeyError(pointer)
    return current


def _stable_camera_identity(value: Mapping[str, object]) -> dict[str, object]:
    fields = (
        "source",
        "camera_id",
        "model",
        "serial",
        "firmware_version",
        "sdk_version",
        "resolution",
        "depth_mode",
        "fps",
        "camera_profile",
    )
    return {field: value[field] for field in fields if field in value}


def _camera_map(value: object) -> dict[str, dict[str, object]]:
    if isinstance(value, Mapping):
        return {
            str(alias): _stable_camera_identity(identity)
            for alias, identity in value.items()
            if isinstance(identity, Mapping)
        }
    if isinstance(value, list):
        result: dict[str, dict[str, object]] = {}
        for identity in value:
            if not isinstance(identity, Mapping):
                continue
            alias = identity.get("alias") or identity.get("role") or identity.get("source")
            if alias:
                camera = identity.get("camera")
                selected = camera if isinstance(camera, Mapping) else identity
                result[str(alias)] = _stable_camera_identity(selected)
        return result
    return {}


def _command_result(
    command_name: str,
    result: Mapping[str, object],
    parser: str | None = None,
) -> dict[str, object]:
    normalized = {
        "returncode": int(result.get("returncode", 0)),
        "stdout": str(result.get("stdout", "")),
        "stderr": str(result.get("stderr", "")),
    }
    stdout = normalized["stdout"]
    assert isinstance(stdout, str)
    selected_parser = parser or command_name
    if selected_parser == "json":
        try:
            normalized["parsed"] = json.loads(stdout)
        except json.JSONDecodeError as exc:
            raise ValueError(f"{command_name} did not produce valid JSON: {exc}") from exc
    elif selected_parser == "number":
        try:
            normalized["parsed"] = float(stdout.strip())
        except ValueError as exc:
            raise ValueError(f"{command_name} did not produce one number") from exc
    elif selected_parser == "boolean":
        value = stdout.strip().lower()
        if value not in {"true", "false"}:
            raise ValueError(f"{command_name} did not produce true or false")
        normalized["parsed"] = value == "true"
    elif selected_parser == "tegrastats":
        temperatures = [float(match.group("value")) for match in _TEMP_RE.finditer(stdout)]
        ram = _RAM_RE.search(stdout)
        normalized["parsed"] = {
            "temperature_c": max(temperatures) if temperatures else None,
            "memory_used_mb": float(ram.group("used")) if ram else None,
            "throttled": (
                False
                if re.search(r"not throttled|no throttling", stdout, re.I)
                else True
                if re.search(r"throttl(?:e|ed|ing)|thermal slowdown", stdout, re.I)
                else None
            ),
        }
    elif selected_parser == "nvpmodel":
        normalized["parsed"] = {"mode": stdout.strip() or None}
    return normalized


def _atomic_write(path: Path, document: Mapping[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(document, handle, indent=2, sort_keys=True)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(Path(temp_name), path)
        parent_fd = os.open(path.parent, os.O_RDONLY)
        try:
            os.fsync(parent_fd)
        finally:
            os.close(parent_fd)
    except BaseException:
        try:
            os.unlink(temp_name)
        except FileNotFoundError:
            pass
        raise


def _new_evidence(
    config: Mapping[str, object],
    config_digest: str,
    truth_rows: Sequence[Mapping[str, object]],
    now: Callable[[], str],
) -> dict[str, object]:
    accepted_profile = json.loads(json.dumps(config))
    truth_corpus = json.loads(json.dumps(list(truth_rows)))
    return {
        "schema_version": EVIDENCE_SCHEMA_VERSION,
        "profile_version": config["profile_version"],
        "production_acceptance": True,
        "config_digest": config_digest,
        "truth_digest": _canonical_digest(truth_corpus),
        "accepted_profile": accepted_profile,
        "truth_corpus": truth_corpus,
        "duration_seconds": config["duration_seconds"],
        "sample_interval_seconds": config["sample_interval_seconds"],
        "started_at": now(),
        "updated_at": now(),
        "completed_duration_seconds": 0.0,
        "status": "running",
        "samples": [],
        "failures": [],
    }


def _load_resume(
    path: Path,
    config: Mapping[str, object],
    config_digest: str,
    truth_rows: Sequence[Mapping[str, object]],
    now: Callable[[], str],
) -> dict[str, object]:
    if not path.exists():
        return _new_evidence(config, config_digest, truth_rows, now)
    truth_digest = _canonical_digest(list(truth_rows))
    try:
        evidence = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ConfigError(f"cannot resume invalid evidence file {path}: {exc}") from exc
    if not isinstance(evidence, dict) or evidence.get("schema_version") != EVIDENCE_SCHEMA_VERSION:
        raise ConfigError("resume evidence schema_version mismatch")
    if evidence.get("config_digest") != config_digest:
        raise ConfigError("resume evidence config_digest mismatch")
    if evidence.get("truth_digest") != truth_digest:
        raise ConfigError("resume evidence truth_digest mismatch")
    if evidence.get("accepted_profile") != config:
        raise ConfigError("resume evidence accepted_profile mismatch")
    if evidence.get("truth_corpus") != list(truth_rows):
        raise ConfigError("resume evidence truth_corpus mismatch")
    if evidence.get("duration_seconds") != config["duration_seconds"]:
        raise ConfigError("resume evidence duration_seconds mismatch")
    if evidence.get("sample_interval_seconds") != config["sample_interval_seconds"]:
        raise ConfigError("resume evidence sample_interval_seconds mismatch")
    if evidence.get("production_acceptance") is not True:
        raise ConfigError("resume evidence production_acceptance must be true")
    if not str(evidence.get("started_at", "")).strip():
        raise ConfigError("resume evidence started_at is required")
    samples = evidence.get("samples")
    if not isinstance(samples, list) or any(
        not isinstance(sample, Mapping) or not str(sample.get("sampled_at", "")).strip()
        for sample in samples
    ):
        raise ConfigError("resume evidence samples must contain timestamped objects")
    try:
        timestamps = _validate_sample_timeline(
            samples,
            started_at=evidence.get("started_at"),
            completed_at=None,
            interval_seconds=float(config["sample_interval_seconds"]),
            enforce_cadence=False,
        )
    except ValueError as exc:
        raise ConfigError(f"resume evidence timeline is invalid: {exc}") from exc
    completed = _number(
        evidence.get("completed_duration_seconds"),
        "resume evidence completed_duration_seconds",
        minimum=0,
    )
    duration = float(config["duration_seconds"])
    interval = float(config["sample_interval_seconds"])
    sample_proven_duration = min(duration, _sampled_active_duration(timestamps, interval))
    if not math.isclose(completed, sample_proven_duration, rel_tol=0, abs_tol=1e-6):
        raise ConfigError(
            "resume evidence completed_duration_seconds does not match its observed timeline"
        )
    evidence["profile_version"] = config["profile_version"]
    evidence["completed_duration_seconds"] = sample_proven_duration
    evidence["status"] = "running"
    evidence.pop("completed_at", None)
    evidence.pop("gates", None)
    evidence.pop("summary", None)
    evidence.pop("identity", None)
    evidence.pop("metrics", None)
    return evidence


def _record_failure(
    evidence: dict[str, object], *, sampled_at: str, kind: str, source: str, error: str
) -> None:
    failures = evidence.setdefault("failures", [])
    assert isinstance(failures, list)
    failures.append(
        {"recorded_at": sampled_at, "kind": kind, "source": source, "error": error}
    )


def _empty_list_errors(
    payload: Mapping[str, object], field: str, *, prefix: str = ""
) -> list[str]:
    label = f"{prefix}.{field}" if prefix else field
    value = payload.get(field)
    if not isinstance(value, list):
        return [f"{label} must be a list"]
    if value:
        return [f"{label} must be empty"]
    return []


def _required_source_errors(payload: Mapping[str, object]) -> list[str]:
    required = payload.get("required_sources")
    if not isinstance(required, Mapping):
        return ["required_sources must be an object"]
    ready = required.get("ready")
    total = required.get("total")
    errors: list[str] = []
    if isinstance(ready, bool) or not isinstance(ready, int) or ready < 0:
        errors.append("required_sources.ready must be a non-negative integer")
    if isinstance(total, bool) or not isinstance(total, int) or total <= 0:
        errors.append("required_sources.total must be positive")
    if not errors and ready != total:
        errors.append(f"required_sources has {ready}/{total} ready")
    return errors


def _blocking_issue_codes(payload: Mapping[str, object]) -> tuple[list[str], list[str]]:
    if "issues" not in payload:
        return [], []
    issues = payload["issues"]
    if not isinstance(issues, list):
        return [], ["issues must be a list"]
    blocking: list[str] = []
    malformed: list[str] = []
    for index, issue in enumerate(issues):
        if not isinstance(issue, Mapping):
            malformed.append(f"issues[{index}] must be an object")
            continue
        severity = str(issue.get("severity", "")).strip().lower()
        state = str(issue.get("state", "")).strip().lower()
        if severity in {"block", "blocking", "critical", "fatal"} or state in {
            "blocked",
            "failed",
        }:
            blocking.append(str(issue.get("code") or f"issues[{index}]"))
    return blocking, malformed


def _endpoint_semantic_errors(path: str, payload: Mapping[str, object]) -> list[str]:
    errors: list[str] = []
    blocking, malformed_issues = _blocking_issue_codes(payload)
    errors.extend(malformed_issues)
    if blocking:
        errors.append(f"blocking issues present: {', '.join(blocking)}")

    if path == "/healthz/live":
        if payload.get("status") != "ok":
            errors.append("status must be ok")
        return errors

    if path == "/api/station/status":
        if not str(payload.get("station_id", "")).strip():
            errors.append("station_id is required")
        camera = payload.get("camera")
        if not isinstance(camera, Mapping):
            errors.append("camera must be an object")
        elif camera.get("state") != "healthy":
            errors.append("camera.state must be healthy")
        if payload.get("calibrated") is not True:
            errors.append("calibrated must be true for production qualification")
        if not str(payload.get("version", "")).strip():
            errors.append("version is required")
        return errors

    if path == "/healthz/ready":
        if payload.get("status") != "ok":
            errors.append("status must be ok")
        if payload.get("state") != "healthy":
            errors.append("state must be healthy")
        errors.extend(_empty_list_errors(payload, "blockers"))
        errors.extend(_required_source_errors(payload))

        calibration = payload.get("calibration")
        if not isinstance(calibration, Mapping):
            errors.append("calibration must be an object")
        else:
            for field in ("expected", "monitor_active", "identity_compatible"):
                if calibration.get(field) is not True:
                    errors.append(
                        f"calibration.{field} must be true for production qualification"
                    )

        pipeline = payload.get("pipeline")
        if not isinstance(pipeline, Mapping):
            errors.append("pipeline must be an object")
            return errors
        if pipeline.get("required") is not True:
            errors.append("pipeline.required must be true for production qualification")
        errors.extend(_empty_list_errors(pipeline, "blockers", prefix="pipeline"))
        health = pipeline.get("health")
        if not isinstance(health, Mapping):
            errors.append("pipeline.health must be an object")
        else:
            if health.get("state") != "healthy":
                errors.append("pipeline.health.state must be healthy")
            errors.extend(
                _empty_list_errors(health, "blockers", prefix="pipeline.health")
            )
        return errors

    if path == "/api/admin/diagnostics":
        errors.extend(_required_source_errors(payload))
        sources = payload.get("camera_sources")
        if not isinstance(sources, list) or not sources:
            errors.append("camera_sources must be a non-empty list")
        else:
            required_sources = 0
            for index, source in enumerate(sources):
                if not isinstance(source, Mapping):
                    errors.append(f"camera_sources[{index}] must be an object")
                    continue
                if source.get("required") is True:
                    required_sources += 1
                    if source.get("state") != "ready":
                        label = source.get("source") or index
                        errors.append(f"camera source {label} must be ready")
                    if source.get("error"):
                        label = source.get("source") or index
                        errors.append(f"camera source {label} has an error")
            if required_sources == 0:
                errors.append("camera_sources must include required sources")
        health = payload.get("pipeline_health")
        if not isinstance(health, Mapping):
            errors.append("pipeline_health must be an object")
        else:
            if health.get("state") != "healthy":
                errors.append("pipeline_health.state must be healthy")
            errors.extend(
                _empty_list_errors(health, "blockers", prefix="pipeline_health")
            )
        return errors

    state = payload.get("state")
    if state is not None and state not in {"healthy", "ready", "ok", "passed"}:
        errors.append("state must be healthy or ready")
    status = payload.get("status")
    if status is not None and status not in {"healthy", "ready", "ok", "passed"}:
        errors.append("status must be healthy or ready")
    if "blockers" in payload:
        errors.extend(_empty_list_errors(payload, "blockers"))
    return errors


def _command_semantic_errors(
    command_name: str,
    parser: str,
    result: Mapping[str, object],
) -> list[str]:
    if parser == "raw":
        return [] if str(result.get("stdout", "")).strip() else ["stdout must not be empty"]

    parsed = result.get("parsed")
    if parser == "number":
        if isinstance(parsed, bool) or not isinstance(parsed, (int, float)):
            return ["parsed number must be numeric"]
        return [] if math.isfinite(float(parsed)) else ["parsed number must be finite"]
    if parser == "boolean":
        return [] if isinstance(parsed, bool) else ["parsed boolean is required"]
    if parser == "nvpmodel":
        if not isinstance(parsed, Mapping) or not str(parsed.get("mode", "")).strip():
            return ["nvpmodel mode is required"]
        return []
    if parser == "tegrastats":
        if not isinstance(parsed, Mapping):
            return ["parsed tegrastats must be an object"]
        errors = []
        for field in ("temperature_c", "memory_used_mb"):
            value = parsed.get(field)
            if (
                isinstance(value, bool)
                or not isinstance(value, (int, float))
                or not math.isfinite(float(value))
            ):
                errors.append(f"tegrastats {field} must be numeric")
        return errors
    if parser != "json":
        return []
    if not isinstance(parsed, Mapping) or not parsed:
        return ["parsed JSON must be a non-empty object"]

    errors: list[str] = []
    state = parsed.get("state")
    if command_name == "station_status":
        if state != "healthy":
            errors.append("state must be healthy")
        if "issues" not in parsed:
            errors.append("issues must be a list")
    elif state is not None and state not in {"healthy", "ready", "ok", "passed"}:
        errors.append("state must be healthy or ready")
    status = parsed.get("status")
    if status is not None and status not in {"healthy", "ready", "ok", "passed"}:
        errors.append("status must be healthy or ready")
    if "blockers" in parsed:
        errors.extend(_empty_list_errors(parsed, "blockers"))
    blocking, malformed_issues = _blocking_issue_codes(parsed)
    errors.extend(malformed_issues)
    if blocking:
        errors.append(f"blocking issues present: {', '.join(blocking)}")
    if command_name == "station_soak":
        command_evidence = parsed.get("evidence")
        if not isinstance(command_evidence, Mapping) or command_evidence.get(
            "production_acceptance"
        ) is not True:
            errors.append("production soak evidence must set production_acceptance to true")
    return errors


def _collect_sample(
    *,
    config: Mapping[str, object],
    evidence: dict[str, object],
    fetch_json: Callable[[str, float], Mapping[str, object]],
    run_command: Callable[[str, Sequence[str], float], Mapping[str, object]],
    now: Callable[[], str],
) -> dict[str, object]:
    sampled_at = now()
    sample: dict[str, object] = {"sampled_at": sampled_at, "endpoints": {}, "commands": {}}
    endpoints = config["endpoints"]
    assert isinstance(endpoints, Mapping)
    timeout = float(config.get("request_timeout_seconds", 10.0))
    for name, endpoint in endpoints.items():
        assert isinstance(endpoint, Mapping)
        path = str(endpoint["path"])
        try:
            payload = fetch_json(path, float(endpoint.get("timeout_seconds", timeout)))
            if not isinstance(payload, Mapping):
                raise ValueError("response is not a JSON object")
            sample["endpoints"][str(name)] = dict(payload)  # type: ignore[index]
            if endpoint.get("required", True):
                semantic_errors = _endpoint_semantic_errors(path, payload)
                if semantic_errors:
                    _record_failure(
                        evidence,
                        sampled_at=sampled_at,
                        kind="endpoint_semantic_error",
                        source=str(name),
                        error="; ".join(semantic_errors),
                    )
        except Exception as exc:  # noqa: BLE001 - failures are qualification evidence
            sample["endpoints"][str(name)] = {"error": str(exc)}  # type: ignore[index]
            if endpoint.get("required", True):
                _record_failure(
                    evidence,
                    sampled_at=sampled_at,
                    kind="endpoint_error",
                    source=str(name),
                    error=str(exc),
                )

    commands = config.get("commands", {})
    assert isinstance(commands, Mapping)
    command_timeout = float(config.get("command_timeout_seconds", 15.0))
    for name, command in commands.items():
        assert isinstance(command, Mapping)
        argv = command["argv"]
        assert isinstance(argv, list)
        try:
            result = _command_result(
                str(name),
                run_command(str(name), argv, float(command.get("timeout_seconds", command_timeout))),
                str(command.get("parser", "raw")),
            )
            sample["commands"][str(name)] = result  # type: ignore[index]
            if result["returncode"] != 0 and command.get("required", True):
                raise RuntimeError(f"exit {result['returncode']}: {result['stderr']}")
            if command.get("required", True):
                semantic_errors = _command_semantic_errors(
                    str(name), str(command.get("parser", "raw")), result
                )
                if semantic_errors:
                    _record_failure(
                        evidence,
                        sampled_at=sampled_at,
                        kind="command_semantic_error",
                        source=str(name),
                        error="; ".join(semantic_errors),
                    )
        except Exception as exc:  # noqa: BLE001 - failures are qualification evidence
            sample["commands"][str(name)] = {"error": str(exc)}  # type: ignore[index]
            if command.get("required", True):
                _record_failure(
                    evidence,
                    sampled_at=sampled_at,
                    kind="command_error",
                    source=str(name),
                    error=str(exc),
                )
    return sample


def _sample_document(sample: Mapping[str, object]) -> dict[str, object]:
    endpoints = sample.get("endpoints", {})
    commands = sample.get("commands", {})
    assert isinstance(endpoints, Mapping) and isinstance(commands, Mapping)
    return {**dict(endpoints), "commands": dict(commands)}


def _extract_series(
    samples: Sequence[Mapping[str, object]], pointer: str
) -> tuple[list[object], list[str]]:
    values: list[object] = []
    missing: list[str] = []
    for sample in samples:
        try:
            values.append(_json_pointer(_sample_document(sample), pointer))
        except KeyError:
            missing.append(str(sample.get("sampled_at", "unknown")))
    return values, missing


def _numeric_series(values: Sequence[object], field: str) -> tuple[list[float], list[str]]:
    result: list[float] = []
    errors: list[str] = []
    for index, value in enumerate(values):
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(float(value)):
            errors.append(f"sample {index + 1}: {field} is not numeric")
        else:
            result.append(float(value))
    return result, errors


def _truth_latency(truth_rows: Sequence[Mapping[str, object]], field: str) -> list[float]:
    return [
        _truth_number(row, field, str(row.get("placement_id", index)))
        for index, row in enumerate(truth_rows, start=1)
    ]


def _recovery_scenario_evidence(
    evidence: Mapping[str, object],
    config: Mapping[str, object],
    samples: Sequence[Mapping[str, object]],
) -> tuple[
    dict[str, object],
    list[str],
    list[tuple[datetime, datetime, str]],
]:
    paths = config["evidence_paths"]
    assert isinstance(paths, Mapping)
    scenario_raw, scenario_missing = _extract_series(
        samples, str(paths["recovery_scenarios"])
    )
    errors: list[str] = []
    actual: dict[str, object] = {}
    interruptions: list[tuple[datetime, datetime, str]] = []
    if scenario_missing:
        errors.append(f"missing in {len(scenario_missing)} samples")
    latest_scenarios = scenario_raw[-1] if scenario_raw else None
    try:
        qualification_started_at = _parse_timestamp(
            evidence.get("started_at"), "qualification started_at"
        )
        qualification_observed_through = _parse_timestamp(
            samples[-1].get("sampled_at") if samples else None,
            "qualification final sampled_at",
        )
    except ValueError as exc:
        errors.append(str(exc))
        qualification_started_at = None
        qualification_observed_through = None
    if not isinstance(latest_scenarios, Mapping):
        errors.append("latest recovery_scenarios must be an object")
        return actual, errors, interruptions

    for name in map(str, config["required_recovery_scenarios"]):
        entry = latest_scenarios.get(name)
        if not isinstance(entry, Mapping):
            errors.append(f"{name} evidence is missing")
            continue
        entry_errors: list[str] = []
        status = str(entry.get("status", "")).strip()
        started_at = str(entry.get("started_at", "")).strip()
        completed_at = str(entry.get("completed_at", "")).strip()
        evidence_ref = str(entry.get("evidence_ref", "")).strip()
        scenario_evidence = entry.get("evidence")
        actual[name] = {
            "status": status,
            "started_at": started_at,
            "completed_at": completed_at,
            "evidence_ref": evidence_ref,
            "evidence": scenario_evidence,
        }
        if status != "passed":
            entry_errors.append(f"{name} status must be passed")

        scenario_started_at: datetime | None = None
        scenario_completed_at: datetime | None = None
        if not started_at or not completed_at:
            entry_errors.append(f"{name} must include start and completion timestamps")
        else:
            try:
                scenario_started_at = _parse_timestamp(started_at, f"{name} started_at")
                scenario_completed_at = _parse_timestamp(
                    completed_at, f"{name} completed_at"
                )
                if scenario_started_at > scenario_completed_at:
                    entry_errors.append(
                        f"{name} completed_at must not precede started_at"
                    )
                if (
                    qualification_started_at is not None
                    and scenario_started_at < qualification_started_at
                ):
                    entry_errors.append(f"{name} started_at predates this qualification run")
                if (
                    qualification_observed_through is not None
                    and scenario_completed_at > qualification_observed_through
                ):
                    entry_errors.append(
                        f"{name} completed_at is outside this qualification run"
                    )
                recovery_timeouts = config["recovery_timeout_seconds"]
                assert isinstance(recovery_timeouts, Mapping)
                timeout_seconds = float(recovery_timeouts[name])
                recovery_duration = (
                    scenario_completed_at - scenario_started_at
                ).total_seconds()
                if recovery_duration > timeout_seconds:
                    entry_errors.append(
                        f"{name} recovery duration {recovery_duration:.3f}s exceeds "
                        f"{timeout_seconds:.3f}s"
                    )
            except ValueError as exc:
                entry_errors.append(str(exc))

        if not evidence_ref:
            entry_errors.append(f"{name} evidence_ref is required")
        if not isinstance(scenario_evidence, Mapping):
            entry_errors.append(f"{name} evidence must be an object")
        else:
            if evidence_ref and evidence_ref != _canonical_digest(scenario_evidence):
                entry_errors.append(
                    f"{name} evidence_ref must match the embedded evidence digest"
                )
            for field in ("fault_injected", "recovered_automatically"):
                if scenario_evidence.get(field) is not True:
                    entry_errors.append(f"{name} evidence.{field} must be true")
            for field in ("expected_result", "observed_result", "operator"):
                if not str(scenario_evidence.get(field, "")).strip():
                    entry_errors.append(f"{name} evidence.{field} is required")
            interventions = scenario_evidence.get("manual_interventions")
            if isinstance(interventions, bool) or interventions != 0:
                entry_errors.append(
                    f"{name} evidence.manual_interventions must be integer 0"
                )
            recovery_log = scenario_evidence.get("log")
            if (
                not isinstance(recovery_log, list)
                or not recovery_log
                or any(not isinstance(item, Mapping) for item in recovery_log)
            ):
                entry_errors.append(f"{name} evidence.log must be a non-empty event array")
            else:
                previous_log_at: datetime | None = None
                observed_phases: list[str] = []
                for index, item in enumerate(recovery_log, start=1):
                    assert isinstance(item, Mapping)
                    if not str(item.get("event", "")).strip():
                        entry_errors.append(
                            f"{name} evidence.log[{index}].event is required"
                        )
                    phase = str(item.get("phase", "")).strip()
                    if phase not in {"fault_injected", "fault_observed", "recovered"}:
                        entry_errors.append(
                            f"{name} evidence.log[{index}].phase must be fault_injected, "
                            "fault_observed, or recovered"
                        )
                    else:
                        observed_phases.append(phase)
                    if not str(item.get("source", "")).strip():
                        entry_errors.append(
                            f"{name} evidence.log[{index}].source is required"
                        )
                    if phase in {"fault_observed", "recovered"}:
                        probe = item.get("probe")
                        if not isinstance(probe, Mapping):
                            entry_errors.append(
                                f"{name} evidence.log[{index}].probe must be an object"
                            )
                        else:
                            if not str(probe.get("name", "")).strip():
                                entry_errors.append(
                                    f"{name} evidence.log[{index}].probe.name is required"
                                )
                            expected_success = phase == "recovered"
                            if probe.get("success") is not expected_success:
                                entry_errors.append(
                                    f"{name} evidence.log[{index}].probe.success must be "
                                    f"{str(expected_success).lower()} for phase {phase}"
                                )
                            if not str(probe.get("detail", "")).strip():
                                entry_errors.append(
                                    f"{name} evidence.log[{index}].probe.detail is required"
                                )
                    try:
                        log_at = _parse_timestamp(
                            item.get("at"), f"{name} evidence.log[{index}].at"
                        )
                        if previous_log_at is not None and log_at < previous_log_at:
                            entry_errors.append(
                                f"{name} evidence.log timestamps must be ordered"
                            )
                        if scenario_started_at is not None and log_at < scenario_started_at:
                            entry_errors.append(
                                f"{name} evidence.log[{index}] predates the scenario"
                            )
                        if scenario_completed_at is not None and log_at > scenario_completed_at:
                            entry_errors.append(
                                f"{name} evidence.log[{index}] follows the scenario"
                            )
                        previous_log_at = log_at
                    except ValueError as exc:
                        entry_errors.append(str(exc))
                required_phases = ["fault_injected", "fault_observed", "recovered"]
                if observed_phases != required_phases:
                    entry_errors.append(
                        f"{name} evidence.log phases must be exactly {required_phases}"
                    )
                if str(scenario_evidence.get("log_digest", "")).strip() != _canonical_digest(
                    recovery_log
                ):
                    entry_errors.append(
                        f"{name} evidence.log_digest must match the embedded log"
                    )

        errors.extend(entry_errors)
        if (
            not entry_errors
            and name in _SAMPLE_INTERRUPTION_SCENARIOS
            and scenario_started_at is not None
            and scenario_completed_at is not None
        ):
            interruptions.append((scenario_started_at, scenario_completed_at, name))
    return actual, errors, interruptions


def _evaluate(
    evidence: dict[str, object],
    config: Mapping[str, object],
    truth_rows: Sequence[Mapping[str, object]],
) -> None:
    samples = evidence["samples"]
    failures = evidence["failures"]
    assert isinstance(samples, list) and isinstance(failures, list)
    paths = config["evidence_paths"]
    limits = config["limits"]
    assert isinstance(paths, Mapping) and isinstance(limits, Mapping)
    gates: list[dict[str, object]] = []

    def gate(name: str, passed: bool, actual: object, limit: object, reason: str = "") -> None:
        gates.append(
            {
                "name": name,
                "passed": bool(passed),
                "actual": actual,
                "limit": limit,
                "reason": reason,
            }
        )

    gate(
        "evidence_complete",
        not failures and bool(samples),
        {"samples": len(samples), "failures": len(failures)},
        {"failures": 0},
        "required API or command evidence is missing" if failures else "",
    )

    scenario_actual, scenario_errors, interruptions = _recovery_scenario_evidence(
        evidence, config, samples
    )
    timeline_errors: list[str] = []
    timeline: list[datetime] = []
    interval = float(config["sample_interval_seconds"])
    duration = float(config["duration_seconds"])
    expected_samples = math.ceil(duration / interval) + 1
    try:
        timeline = _validate_sample_timeline(
            samples,
            started_at=evidence.get("started_at"),
            completed_at=evidence.get("completed_at"),
            interval_seconds=interval,
            allowed_interruptions=interruptions,
        )
    except ValueError as exc:
        timeline_errors.append(str(exc))
    if len(samples) < expected_samples:
        timeline_errors.append(
            f"{len(samples)} samples recorded; at least {expected_samples} are required"
        )
    active_duration = _sampled_active_duration(timeline, interval)
    if active_duration < duration:
        timeline_errors.append(
            f"active sampled duration {active_duration:.3f}s is shorter than {duration:.3f}s"
        )
    gate(
        "sample_timeline",
        not timeline_errors,
        {
            "samples": len(samples),
            "active_duration_seconds": active_duration,
            "wall_duration_seconds": (
                (timeline[-1] - timeline[0]).total_seconds() if timeline else None
            ),
            "approved_interruptions": [name for _start, _end, name in interruptions],
        },
        {
            "minimum_samples": expected_samples,
            "minimum_active_duration_seconds": duration,
            "maximum_unexplained_gap_seconds": (
                interval + SAMPLE_TIMESTAMP_TOLERANCE_SECONDS
            ),
        },
        "; ".join(timeline_errors),
    )

    identity: dict[str, object] = {"version": None, "digest": None, "cameras": {}}
    identity_errors: list[str] = []
    for field in ("version", "digest"):
        values, missing = _extract_series(samples, str(paths[field]))
        normalized = {str(value).strip() for value in values if str(value).strip()}
        if missing or len(normalized) != 1:
            identity_errors.append(f"{field} missing or changed")
        elif normalized:
            identity[field] = next(iter(normalized))
    digest = identity.get("digest")
    if digest is not None and _DIGEST_RE.fullmatch(str(digest)) is None:
        identity_errors.append("digest is not an immutable sha256 digest")
    camera_values, camera_missing = _extract_series(samples, str(paths["camera_identities"]))
    required_cameras = [str(value) for value in config["required_cameras"]]  # type: ignore[index]
    stable_cameras: dict[str, dict[str, object]] | None = None
    for raw_cameras in camera_values:
        cameras = _camera_map(raw_cameras)
        selected = {alias: cameras.get(alias, {}) for alias in required_cameras}
        for alias, camera in selected.items():
            if not camera or not str(camera.get("serial", "")).strip():
                identity_errors.append(f"camera {alias} identity missing")
        if stable_cameras is None:
            stable_cameras = selected
        elif selected != stable_cameras:
            identity_errors.append("camera identities changed")
    if camera_missing or not camera_values:
        identity_errors.append("camera identities missing")
    identity["cameras"] = stable_cameras or {}
    gate(
        "runtime_identity",
        not identity_errors,
        identity,
        {"stable_version": True, "stable_digest": True, "required_cameras": required_cameras},
        "; ".join(sorted(set(identity_errors))),
    )

    dimension_metrics: dict[str, dict[str, float | int]] = {}
    placement_coverage: dict[str, int] = {}
    accuracy_errors: list[str] = []
    if not truth_rows:
        gate(
            "dimension_accuracy",
            False,
            None,
            limits["dimension_error_mm"],
            "caliper-truthed placement input is required",
        )
    else:
        try:
            dimension_metrics = calculate_dimension_metrics(truth_rows)
            coverage: Counter[tuple[str, str]] = Counter()
            for index, row in enumerate(truth_rows, start=1):
                object_id = str(row.get("truth_object_id", "")).strip()
                orientation = str(row.get("orientation", "")).strip()
                if not object_id or not orientation:
                    raise ValueError(
                        f"truth row {index}: truth_object_id and orientation are required"
                    )
                coverage[(object_id, orientation)] += 1
            placement_coverage = {
                f"{object_id}/{orientation}": count
                for (object_id, orientation), count in sorted(coverage.items())
            }
            class_limits = limits["dimension_error_mm"]
            assert isinstance(class_limits, Mapping)
            minimum = int(float(limits["min_placements_per_class"]))
            coverage_minimum = int(
                float(limits["min_placements_per_object_orientation"])
            )
            for label, count in placement_coverage.items():
                if count < coverage_minimum:
                    accuracy_errors.append(
                        f"{label} has {count} placements; requires {coverage_minimum}"
                    )
            for class_name, expected in class_limits.items():
                actual = dimension_metrics.get(str(class_name))
                if actual is None:
                    accuracy_errors.append(f"class {class_name} has no truth placements")
                    continue
                assert isinstance(expected, Mapping)
                if int(actual["placements"]) < minimum:
                    accuracy_errors.append(
                        f"class {class_name} has {actual['placements']} placements; requires {minimum}"
                    )
                for percentile in ("p50", "p95", "max"):
                    actual_key = f"{percentile}_error_mm"
                    if float(actual[actual_key]) > float(expected[percentile]):
                        accuracy_errors.append(
                            f"{class_name} {percentile} {actual[actual_key]} > {expected[percentile]} mm"
                        )
            extras = set(dimension_metrics) - set(map(str, class_limits))
            if extras:
                accuracy_errors.append(f"truth classes lack accepted limits: {sorted(extras)}")
            gate(
                "dimension_accuracy",
                not accuracy_errors,
                dimension_metrics,
                class_limits,
                "; ".join(accuracy_errors),
            )
        except ValueError as exc:
            gate("dimension_accuracy", False, None, limits["dimension_error_mm"], str(exc))

    latency_metrics: dict[str, object] = {}
    for field, limit_name, gate_name in (
        ("settle_latency_ms", "settle_latency_ms_p95", "settle_latency"),
        ("capture_latency_ms", "capture_latency_ms_p95", "capture_latency"),
    ):
        try:
            values = _truth_latency(truth_rows, field) if truth_rows else []
            actual = _percentile(values, 0.95) if values else None
            latency_metrics[f"{field}_p95"] = actual
            gate(
                gate_name,
                actual is not None and actual <= float(limits[limit_name]),
                actual,
                limits[limit_name],
                "caliper-truthed placement latency input is required" if actual is None else "",
            )
        except ValueError as exc:
            gate(gate_name, False, None, limits[limit_name], str(exc))

    telemetry: dict[str, object] = {}
    telemetry_specs = (
        ("temperature_c", "max_temperature_c", "max", lambda values: max(values)),
        ("rss_mb", "max_rss_mb", "max", lambda values: max(values)),
        ("event_loss_count", "max_event_loss_count", "max", lambda values: max(values)),
        ("manual_interventions", "max_manual_interventions", "max", lambda values: max(values)),
    )
    for field, limit_name, label, reduce_values in telemetry_specs:
        raw, missing = _extract_series(samples, str(paths[field]))
        values, errors = _numeric_series(raw, field)
        actual = reduce_values(values) if values else None
        telemetry[f"{label}_{field}"] = actual
        reason_parts = [*errors]
        if missing:
            reason_parts.append(f"missing in {len(missing)} samples")
        gate(
            field,
            actual is not None and not reason_parts and actual <= float(limits[limit_name]),
            actual,
            limits[limit_name],
            "; ".join(reason_parts),
        )

    throttle_raw, throttle_missing = _extract_series(samples, str(paths["throttle_active"]))
    throttle_errors = [
        f"throttle_active sample {index} must be boolean"
        for index, value in enumerate(throttle_raw)
        if not isinstance(value, bool)
    ]
    throttled_samples = (
        sum(value is True for value in throttle_raw)
        if not throttle_errors and not throttle_missing
        else None
    )
    telemetry["throttled_samples"] = throttled_samples
    throttle_reasons = [*throttle_errors]
    if throttle_missing:
        throttle_reasons.append(f"missing in {len(throttle_missing)} samples")
    gate(
        "throttling",
        throttled_samples is not None
        and not throttle_reasons
        and throttled_samples <= int(float(limits["max_throttled_samples"])),
        throttled_samples,
        limits["max_throttled_samples"],
        "; ".join(throttle_reasons),
    )

    gate(
        "recovery_scenarios",
        not scenario_errors,
        scenario_actual,
        {
            "required": list(config["required_recovery_scenarios"]),
            "timeout_seconds": config["recovery_timeout_seconds"],
        },
        "; ".join(scenario_errors),
    )

    evidence["identity"] = identity
    evidence["metrics"] = {
        "dimension_error_by_class": dimension_metrics,
        "placement_coverage": placement_coverage,
        **latency_metrics,
        **telemetry,
    }
    evidence["gates"] = gates
    evidence["summary"] = {
        "samples": len(samples),
        "failures": len(failures),
        "passed_gates": sum(bool(item["passed"]) for item in gates),
        "total_gates": len(gates),
    }
    evidence["status"] = "passed" if all(bool(item["passed"]) for item in gates) else "failed"


def run_qualification(
    *,
    config: Mapping[str, object],
    config_digest: str,
    truth_rows: Sequence[Mapping[str, object]],
    evidence_path: Path,
    fetch_json: Callable[[str, float], Mapping[str, object]],
    run_command: Callable[[str, Sequence[str], float], Mapping[str, object]],
    monotonic: Callable[[], float] = time.monotonic,
    now: Callable[[], str],
    wait: Callable[[float], None] = time.sleep,
) -> dict[str, object]:
    """Collect samples, checkpoint each atomically, and evaluate all gates."""
    validate_config(config)
    evidence = _load_resume(
        evidence_path,
        config,
        config_digest,
        truth_rows,
        now,
    )
    samples = evidence.setdefault("samples", [])
    assert isinstance(samples, list)
    duration = float(config["duration_seconds"])
    interval = float(config["sample_interval_seconds"])
    completed = min(duration, float(evidence.get("completed_duration_seconds", 0.0)))

    if not samples:
        samples.append(
            _collect_sample(
                config=config,
                evidence=evidence,
                fetch_json=fetch_json,
                run_command=run_command,
                now=now,
            )
        )
        evidence["completed_duration_seconds"] = completed
        evidence["updated_at"] = now()
        _atomic_write(evidence_path, evidence)

    next_deadline = monotonic()
    while completed < duration:
        step = min(interval, duration - completed)
        next_deadline += step
        delay = next_deadline - monotonic()
        if delay > 0:
            wait(delay)
        samples.append(
            _collect_sample(
                config=config,
                evidence=evidence,
                fetch_json=fetch_json,
                run_command=run_command,
                now=now,
            )
        )
        completed += step
        evidence["completed_duration_seconds"] = completed
        evidence["updated_at"] = now()
        _atomic_write(evidence_path, evidence)

    evidence["completed_duration_seconds"] = completed
    _evaluate(evidence, config, truth_rows)
    evidence["completed_at"] = now()
    evidence["updated_at"] = evidence["completed_at"]
    _atomic_write(evidence_path, evidence)
    return evidence


def _load_json(path: Path) -> object:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ConfigError(f"cannot read JSON from {path}: {exc}") from exc


def load_truth(path: Path | None) -> list[dict[str, object]]:
    if path is None:
        return []
    if path.suffix.lower() == ".csv":
        try:
            with path.open(newline="", encoding="utf-8") as handle:
                return [dict(row) for row in csv.DictReader(handle)]
        except OSError as exc:
            raise ConfigError(f"cannot read truth CSV from {path}: {exc}") from exc
    document = _load_json(path)
    if isinstance(document, Mapping):
        document = document.get("placements")
    if not isinstance(document, list) or any(not isinstance(row, Mapping) for row in document):
        raise ConfigError("truth JSON must be a list or an object containing a placements list")
    return [dict(row) for row in document]


def parse_duration(value: str) -> float:
    match = _DURATION_RE.fullmatch(value.strip())
    if match is None:
        raise argparse.ArgumentTypeError("duration must be a positive number with s, m, or h")
    seconds = float(match.group("value")) * {None: 1, "s": 1, "m": 60, "h": 3600}[
        match.group("unit")
    ]
    if seconds <= 0:
        raise argparse.ArgumentTypeError("duration must be greater than zero")
    return seconds


def _utc_now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _http_fetcher(base_url: str, headers: Mapping[str, str]) -> Callable[[str, float], Mapping[str, object]]:
    base = base_url.rstrip("/")
    parsed_base = urllib.parse.urlparse(base)
    host = parsed_base.hostname or ""
    try:
        loopback = host.lower() == "localhost" or ipaddress.ip_address(host).is_loopback
    except ValueError:
        loopback = False
    if parsed_base.scheme not in {"http", "https"} or not loopback:
        raise ConfigError("qualification base URL must be an HTTP(S) loopback URL")

    class RejectRedirects(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, request, file_pointer, code, message, headers, new_url):  # type: ignore[no-untyped-def]
            raise urllib.error.HTTPError(
                request.full_url,
                code,
                "redirects are not allowed for authenticated qualification requests",
                headers,
                file_pointer,
            )

    opener = urllib.request.build_opener(RejectRedirects())

    def fetch(path: str, timeout: float) -> Mapping[str, object]:
        request = urllib.request.Request(f"{base}{path}", headers=dict(headers))
        try:
            with opener.open(request, timeout=timeout) as response:  # noqa: S310
                payload = json.loads(response.read())
        except urllib.error.HTTPError as exc:
            raise RuntimeError(f"HTTP {exc.code}") from exc
        except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as exc:
            raise RuntimeError(str(exc)) from exc
        if not isinstance(payload, Mapping):
            raise RuntimeError("response is not a JSON object")
        return payload

    return fetch


def _subprocess_runner(
    _name: str, argv: Sequence[str], timeout: float
) -> Mapping[str, object]:
    completed = subprocess.run(  # noqa: S603 - argv is explicit qualification config
        list(argv),
        check=False,
        capture_output=True,
        text=True,
        timeout=timeout,
    )
    return {
        "returncode": completed.returncode,
        "stdout": completed.stdout,
        "stderr": completed.stderr,
    }


def _config_digest(config: Mapping[str, object]) -> str:
    return _canonical_digest(config)


def _command_override(value: str) -> tuple[str, list[str]]:
    if "=" not in value:
        raise argparse.ArgumentTypeError("command override must be NAME=COMMAND")
    name, raw_command = value.split("=", 1)
    argv = shlex.split(raw_command)
    if not name.strip() or not argv:
        raise argparse.ArgumentTypeError("command override must be NAME=COMMAND")
    return name.strip(), argv


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--config", required=True, type=Path, help="Versioned qualification profile JSON."
    )
    parser.add_argument("--truth", type=Path, help="Caliper-truthed placement CSV or JSON.")
    parser.add_argument(
        "--evidence",
        required=True,
        type=Path,
        help="Atomic, resumable evidence JSON path.",
    )
    parser.add_argument("--base-url", required=True, help="Vision station API base URL.")
    parser.add_argument(
        "--duration",
        type=parse_duration,
        help="Override production duration with 72h or longer.",
    )
    parser.add_argument(
        "--sample-interval",
        type=parse_duration,
        help="Override production sample interval with at most 60s.",
    )
    parser.add_argument(
        "--command",
        action="append",
        default=[],
        type=_command_override,
        metavar="NAME=COMMAND",
        help="Override/add an explicit argv command such as tegrastats or nvpmodel.",
    )
    parser.add_argument(
        "--station-api-key-file",
        type=Path,
        help="Optional file used for X-Station-Api-Key.",
    )
    parser.add_argument(
        "--agent-private-key",
        required=True,
        type=Path,
        help="Existing appliance agent ECDSA private key used to attest final evidence.",
    )
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = _build_parser().parse_args(argv)
    try:
        document = _load_json(args.config)
        if not isinstance(document, Mapping):
            raise ConfigError("qualification config must be a JSON object")
        config = dict(document)
        if args.duration is not None:
            config["duration_seconds"] = args.duration
        if args.sample_interval is not None:
            config["sample_interval_seconds"] = args.sample_interval
        commands = dict(config.get("commands", {}))
        for name, command_argv in args.command:
            command = dict(commands.get(name, {}))
            command.update({"argv": command_argv, "required": True})
            commands[name] = command
        config["commands"] = commands
        validate_config(config)
        _validate_agent_private_key(args.agent_private_key)
        truth_rows = load_truth(args.truth)
        headers: dict[str, str] = {}
        if args.station_api_key_file is not None:
            headers["X-Station-Api-Key"] = args.station_api_key_file.read_text(
                encoding="utf-8"
            ).strip()
        result = run_qualification(
            config=config,
            config_digest=_config_digest(config),
            truth_rows=truth_rows,
            evidence_path=args.evidence,
            fetch_json=_http_fetcher(args.base_url, headers),
            run_command=_subprocess_runner,
            now=_utc_now,
        )
        _sign_evidence(result, args.agent_private_key)
        _atomic_write(args.evidence, result)
    except (ConfigError, OSError, ValueError) as exc:
        print(json.dumps({"status": "error", "error": str(exc)}, indent=2))
        return 2
    print(json.dumps({"status": result["status"], "evidence": str(args.evidence)}))
    return 0 if result["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
